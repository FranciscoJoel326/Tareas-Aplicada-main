using RegistrodeLibros.Context;
using Microsoft.EntityFrameworkCore;
using RegistrodeLibros.Components;
using RegistrodeLibros.Extensors;
using RegistrodeLibros.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents();

var ConStr = builder.Configuration.GetConnectionString("ConStr");

builder.Services.AddDbContextFactory<Contexto>(o => o.UseSqlServer(ConStr));

builder.Services.AddScoped<LibrosServices>();
builder.Services.AddScoped<EstudiantesServices>();
builder.Services.AddScoped<PrestamosServices>();
builder.Services.AddScoped<DevolucionesServices>();
builder.Services.AddScoped<EntradaLibrosServices>();
builder.Services.AddScoped<SalidaLibrosServices>();
builder.Services.AddScoped<AutoresServices>();
builder.Services.AddScoped<CategoriasServices>();
builder.Services.AddScoped<EditorialesServices>();

builder.Services.AddBlazorBootstrap();


var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();

app.UseAntiforgery();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode();

app.Run();
