using Aplicada1.Core;
using Microsoft.EntityFrameworkCore;
using RegistrodeLibros.Context;
using RegistrodeLibros.Models;
using System.Linq.Expressions;

namespace RegistrodeLibros.Services;

public class SalidaLibrosServices(IDbContextFactory<Contexto> contextFactory) : IServiceResult<SalidaLibros, int>
{
    public async Task<Result> Guardar(SalidaLibros salida)
    {
        if (!await Existe(salida.SalidaId))
        {
            return await Insertar(salida);
        }
        return await Modificar(salida);
    }

    public async Task<bool> Existe(int salidaId)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.SalidaLibros.AnyAsync(s => s.SalidaId == salidaId);
    }

    private async Task<Result> Insertar(SalidaLibros salida)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();

        var error = await AfectarLibros(contexto, salida.SalidaLibrosDetalle, Operacion.Resta);
        if (error != null) return Result.Failure(error);

        foreach (var d in salida.SalidaLibrosDetalle) d.Libro = null!;
        contexto.SalidaLibros.Add(salida);
        return Result.Success(await contexto.SaveChangesAsync() > 0);
    }

    private async Task<Result> Modificar(SalidaLibros salida)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();

        var anterior = await contexto.SalidaLibros
            .Include(s => s.SalidaLibrosDetalle)
            .FirstOrDefaultAsync(s => s.SalidaId == salida.SalidaId);

        if (anterior == null)
            return Result.Failure(new Error("Salida.NoEncontrada", "La salida no fue encontrada."));

        // Devuelve al inventario lo que habia salido antes y aplica lo nuevo
        await AfectarLibros(contexto, anterior.SalidaLibrosDetalle, Operacion.Suma);
        var error = await AfectarLibros(contexto, salida.SalidaLibrosDetalle, Operacion.Resta);
        if (error != null) return Result.Failure(error);

        contexto.SalidaLibrosDetalle.RemoveRange(anterior.SalidaLibrosDetalle);
        anterior.Fecha = salida.Fecha;
        anterior.Concepto = salida.Concepto;
        anterior.Total = salida.Total;

        foreach (var d in salida.SalidaLibrosDetalle)
        {
            anterior.SalidaLibrosDetalle.Add(new SalidaLibrosDetalle
            {
                LibroId = d.LibroId,
                Cantidad = d.Cantidad
            });
        }

        return Result.Success(await contexto.SaveChangesAsync() > 0);
    }

    private static async Task<Error?> AfectarLibros(Contexto contexto, IEnumerable<SalidaLibrosDetalle> detalle, Operacion operacion)
    {
        foreach (var item in detalle)
        {
            var libro = await contexto.Libros.SingleAsync(l => l.LibroID == item.LibroId);

            if (operacion == Operacion.Suma)
            {
                libro.CantidadLibros += item.Cantidad;
            }
            else
            {
                if (libro.CantidadLibros < item.Cantidad)
                    return new Error("Salida.StockInsuficiente", $"No hay suficiente existencia de '{libro.Titulo}'.");
                libro.CantidadLibros -= item.Cantidad;
            }
        }
        return null;
    }

    public async Task<Result<SalidaLibros?>> Buscar(int salidaId)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.SalidaLibros
            .Include(s => s.SalidaLibrosDetalle).ThenInclude(d => d.Libro)
            .FirstOrDefaultAsync(s => s.SalidaId == salidaId);
    }

    public async Task<Result<List<SalidaLibros>>> GetList(Expression<Func<SalidaLibros, bool>> criterio)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.SalidaLibros
            .Include(s => s.SalidaLibrosDetalle).ThenInclude(d => d.Libro)
            .Where(criterio).AsNoTracking().ToListAsync();
    }

    public async Task<Result> Eliminar(int salidaId)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        var salida = await contexto.SalidaLibros
            .Include(s => s.SalidaLibrosDetalle)
            .FirstOrDefaultAsync(s => s.SalidaId == salidaId);

        if (salida == null)
            return Result.Failure(new Error("Salida.NoEncontrada", "La salida no fue encontrada."));

        await AfectarLibros(contexto, salida.SalidaLibrosDetalle, Operacion.Suma);
        contexto.SalidaLibrosDetalle.RemoveRange(salida.SalidaLibrosDetalle);
        contexto.SalidaLibros.Remove(salida);
        return Result.Success(await contexto.SaveChangesAsync() > 0);
    }

    private enum Operacion { Suma = 1, Resta = 2 }
}
