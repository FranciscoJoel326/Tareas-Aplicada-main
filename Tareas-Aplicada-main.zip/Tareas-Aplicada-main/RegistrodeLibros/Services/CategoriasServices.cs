using Aplicada1.Core;
using Microsoft.EntityFrameworkCore;
using RegistrodeLibros.Context;
using RegistrodeLibros.Models;
using System.Linq.Expressions;

namespace RegistrodeLibros.Services;

public class CategoriasServices(IDbContextFactory<Contexto> contextFactory) : IServiceResult<Categorias, int>
{
    public async Task<Result> Guardar(Categorias item)
    {
        if (!await Existe(item.CategoriaId))
        {
            if (await ExisteNombre(item.Nombre))
            {
                return Result.Failure(new Error("Duplicado", "Ya existe un registro con ese nombre"));
            }

            var inserto = await Insertar(item);
            return Result.Success(inserto);
        }
        else
        {
            var modifico = await Modificar(item);
            return Result.Success(modifico);
        }
    }

    private async Task<bool> Existe(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Categorias.AnyAsync(x => x.CategoriaId == id);
    }

    private async Task<bool> ExisteNombre(string valor)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Categorias.AnyAsync(x => x.Nombre == valor);
    }

    private async Task<bool> Insertar(Categorias item)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        contexto.Categorias.Add(item);
        return await contexto.SaveChangesAsync() > 0;
    }

    private async Task<bool> Modificar(Categorias item)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        contexto.Update(item);
        return await contexto.SaveChangesAsync() > 0;
    }

    public async Task<Result<Categorias?>> Buscar(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Categorias.FirstOrDefaultAsync(x => x.CategoriaId == id);
    }

    public async Task<Result<List<Categorias>>> GetList(Expression<Func<Categorias, bool>> criterio)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Categorias.Where(criterio).AsNoTracking().ToListAsync();
    }

    public async Task<Result> Eliminar(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        var eliminado = await contexto.Categorias.Where(x => x.CategoriaId == id).ExecuteDeleteAsync() > 0;
        return Result.Success(eliminado);
    }
}
