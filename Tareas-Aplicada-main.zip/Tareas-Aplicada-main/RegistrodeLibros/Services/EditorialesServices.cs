using Aplicada1.Core;
using Microsoft.EntityFrameworkCore;
using RegistrodeLibros.Context;
using RegistrodeLibros.Models;
using System.Linq.Expressions;

namespace RegistrodeLibros.Services;

public class EditorialesServices(IDbContextFactory<Contexto> contextFactory) : IServiceResult<Editoriales, int>
{
    public async Task<Result> Guardar(Editoriales item)
    {
        if (!await Existe(item.EditorialId))
        {
            if (await ExisteNombre(item.Nombre))
            {
                return Result.Failure(new Error("Duplicado", "Ya existe un registro con ese nombre"));
            }

            var inserto = await Insertar(item);
            return Result.Success(inserto);
        }
        else
        {
            var modifico = await Modificar(item);
            return Result.Success(modifico);
        }
    }

    private async Task<bool> Existe(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Editoriales.AnyAsync(x => x.EditorialId == id);
    }

    private async Task<bool> ExisteNombre(string valor)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Editoriales.AnyAsync(x => x.Nombre == valor);
    }

    private async Task<bool> Insertar(Editoriales item)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        contexto.Editoriales.Add(item);
        return await contexto.SaveChangesAsync() > 0;
    }

    private async Task<bool> Modificar(Editoriales item)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        contexto.Update(item);
        return await contexto.SaveChangesAsync() > 0;
    }

    public async Task<Result<Editoriales?>> Buscar(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Editoriales.FirstOrDefaultAsync(x => x.EditorialId == id);
    }

    public async Task<Result<List<Editoriales>>> GetList(Expression<Func<Editoriales, bool>> criterio)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Editoriales.Where(criterio).AsNoTracking().ToListAsync();
    }

    public async Task<Result> Eliminar(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        var eliminado = await contexto.Editoriales.Where(x => x.EditorialId == id).ExecuteDeleteAsync() > 0;
        return Result.Success(eliminado);
    }
}
