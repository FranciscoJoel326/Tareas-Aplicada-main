using Aplicada1.Core;
using Microsoft.EntityFrameworkCore;
using RegistrodeLibros.Context;
using RegistrodeLibros.Models;
using System.Linq.Expressions;

namespace RegistrodeLibros.Services;

public class AutoresServices(IDbContextFactory<Contexto> contextFactory) : IServiceResult<Autores, int>
{
    public async Task<Result> Guardar(Autores item)
    {
        if (!await Existe(item.AutorId))
        {
            if (await ExisteNombre(item.Nombres))
            {
                return Result.Failure(new Error("Duplicado", "Ya existe un registro con ese nombre"));
            }

            var inserto = await Insertar(item);
            return Result.Success(inserto);
        }
        else
        {
            var modifico = await Modificar(item);
            return Result.Success(modifico);
        }
    }

    private async Task<bool> Existe(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Autores.AnyAsync(x => x.AutorId == id);
    }

    private async Task<bool> ExisteNombre(string valor)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Autores.AnyAsync(x => x.Nombres == valor);
    }

    private async Task<bool> Insertar(Autores item)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        contexto.Autores.Add(item);
        return await contexto.SaveChangesAsync() > 0;
    }

    private async Task<bool> Modificar(Autores item)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        contexto.Update(item);
        return await contexto.SaveChangesAsync() > 0;
    }

    public async Task<Result<Autores?>> Buscar(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Autores.FirstOrDefaultAsync(x => x.AutorId == id);
    }

    public async Task<Result<List<Autores>>> GetList(Expression<Func<Autores, bool>> criterio)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        return await contexto.Autores.Where(criterio).AsNoTracking().ToListAsync();
    }

    public async Task<Result> Eliminar(int id)
    {
        await using var contexto = await contextFactory.CreateDbContextAsync();
        var eliminado = await contexto.Autores.Where(x => x.AutorId == id).ExecuteDeleteAsync() > 0;
        return Result.Success(eliminado);
    }
}
