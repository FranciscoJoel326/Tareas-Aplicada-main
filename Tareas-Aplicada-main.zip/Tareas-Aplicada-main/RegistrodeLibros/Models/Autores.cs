using System.ComponentModel.DataAnnotations;

namespace RegistrodeLibros.Models;

public class Autores
{
    [Key]
    public int AutorId { get; set; }

    [Required(ErrorMessage = "Este campo es obligatorio")]
    public string Nombres { get; set; } = null!;

    [Required(ErrorMessage = "Este campo es obligatorio")]
    public string Nacionalidad { get; set; } = null!;
}
