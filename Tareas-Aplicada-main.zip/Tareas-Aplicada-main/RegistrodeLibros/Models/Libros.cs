namespace RegistrodeLibros.Models;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
public class Libros
{
    [Key]
    public int LibroID { get; set;}

    [Required(ErrorMessage = "El campo de Titulo es Obligatorio")]
    public string? Titulo { get; set; } = null!;

    [Required(ErrorMessage = "El campo de Autor es Requerido")]
    public string? Autor { get; set; } = null!;

    [Required(ErrorMessage ="El campo de AnoPublicacion es obligatorio")]
    public int AnoPublicacion {get; set;}

    public bool Disponible { get; set; } = true;

    public int CantidadLibros { get; set; }

    public int? AutorId { get; set; }
    public int? CategoriaId { get; set; }
    public int? EditorialId { get; set; }

    [ForeignKey("AutorId")]
    public virtual Autores? AutorRef { get; set; }

    [ForeignKey("CategoriaId")]
    public virtual Categorias? Categoria { get; set; }

    [ForeignKey("EditorialId")]
    public virtual Editoriales? Editorial { get; set; }
}
