using System.ComponentModel.DataAnnotations;

namespace RegistrodeLibros.Models;

public class Editoriales
{
    [Key]
    public int EditorialId { get; set; }

    [Required(ErrorMessage = "Este campo es obligatorio")]
    public string Nombre { get; set; } = null!;

    [Required(ErrorMessage = "Este campo es obligatorio")]
    public string Pais { get; set; } = null!;
}
