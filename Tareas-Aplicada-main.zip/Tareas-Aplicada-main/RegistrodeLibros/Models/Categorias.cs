using System.ComponentModel.DataAnnotations;

namespace RegistrodeLibros.Models;

public class Categorias
{
    [Key]
    public int CategoriaId { get; set; }

    [Required(ErrorMessage = "Este campo es obligatorio")]
    public string Nombre { get; set; } = null!;

    [Required(ErrorMessage = "Este campo es obligatorio")]
    public string Descripcion { get; set; } = null!;
}
