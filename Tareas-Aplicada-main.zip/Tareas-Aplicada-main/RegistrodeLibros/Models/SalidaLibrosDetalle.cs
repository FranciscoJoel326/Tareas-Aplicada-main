using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RegistrodeLibros.Models;

public class SalidaLibrosDetalle
{
    [Key]
    public int Id { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Ingrese un Id valido")]
    public int SalidaId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Ingrese un Id valido")]
    public int LibroId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Ingrese una Cantidad valida")]
    public int Cantidad { get; set; }

    [ForeignKey("LibroId")]
    public virtual Libros Libro { get; set; } = null!;

    [ForeignKey("SalidaId")]
    [InverseProperty("SalidaLibrosDetalle")]
    public virtual SalidaLibros Salida { get; set; } = null!;
}
