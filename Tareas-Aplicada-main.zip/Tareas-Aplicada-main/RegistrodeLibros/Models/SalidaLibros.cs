using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace RegistrodeLibros.Models;

public class SalidaLibros
{
    [Key]
    public int SalidaId { get; set; }

    [Required(ErrorMessage = "Elija una fecha valida")]
    public DateOnly Fecha { get; set; } = DateOnly.FromDateTime(DateTime.Now);

    [Required(ErrorMessage = "Este campo es obligatorio")]
    public string? Concepto { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Debe introducir una cantidad valida")]
    public int Total { get; set; }

    [InverseProperty("Salida")]
    public virtual ICollection<SalidaLibrosDetalle> SalidaLibrosDetalle { get; set; } = new List<SalidaLibrosDetalle>();
}
