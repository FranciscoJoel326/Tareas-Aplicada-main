namespace RegistrodeLibros.Context;
using Microsoft.EntityFrameworkCore;
using RegistrodeLibros.Models;

public class Contexto : DbContext
{   
    public Contexto(DbContextOptions<Contexto> options) : base(options) {}
    public DbSet<Libros> Libros {get; set;}
    public DbSet<Estudiantes> Estudiantes {get; set; }
    public DbSet<PrestamoLibros> Prestamos { get; set; }
    public DbSet<EntradaLibros> EntradaLibros { get; set; }
    public DbSet<EntradaLibrosDetalle> EntradaLibrosDetalle { get; set; }


    public DbSet<Devoluciones> Devoluciones { get; set; }
    public DbSet<Autores> Autores { get; set; }
    public DbSet<Categorias> Categorias { get; set; }
    public DbSet<Editoriales> Editoriales { get; set; }
    public DbSet<SalidaLibros> SalidaLibros { get; set; }
    public DbSet<SalidaLibrosDetalle> SalidaLibrosDetalle { get; set; }
}
